﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace THA_WEEK_8_Michelle_P
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string ConnectionString;
        string sqlQuery;
        DataTable datapemain = new DataTable();
        DataTable datateam = new DataTable();
        DataTable datateammain = new DataTable();
        int yellow = 0;
        int red = 0;
        int goal = 0;
        int penalty = 0;


        private void Form1_Load(object sender, EventArgs e)
        {
            ConnectionString = "server=127.0.0.1;uid=root;pwd=Michelle18112004;database=premier_league";
            sqlConnect= new MySqlConnection(ConnectionString);
            sqlConnect.Open();
            pnl_player.Visible = false;
            pnl_showmatch.Visible = false;
        }

        private void playerDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sqlQuery = "select t.team_name , t.team_id from team t;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(datateam);
            cmb_team.DataSource = datateam;
            cmb_team.DisplayMember = "team_name";
            cmb_team.ValueMember = "team_id";
            pnl_player.Visible = true;
            pnl_showmatch.Visible = false;
        }

        private void showMatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_player.Visible = false;
            pnl_showmatch.Visible = true;
        }

        private void cmb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            datapemain.Clear();
            string simpan1 = cmb_team.SelectedValue.ToString();
            sqlQuery = $"SELECT player_name as 'nama player' FROM player p where p.team_id = '{simpan1}';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(datapemain);
            cmb_player.DataSource = datapemain;
            cmb_player.DisplayMember = "nama player";
            cmb_player.Visible = true;
            
        }

        private void cmb_player_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            datateammain = new DataTable();
            string simpan1 = cmb_player.GetItemText(cmb_player.SelectedItem).ToString();
            string simpan2 = cmb_team.GetItemText(cmb_team.SelectedItem).ToString();

            sqlQuery = $"SELECT p.player_name as 'nama player', t.team_name as 'nama team', n.nation as 'nationality',p.playing_pos as 'play',p.team_number as 'squad number' FROM player p,nationality n,team t where player_name = '{simpan1}' and team_name = '{simpan2}' and p.nationality_id = n.nationality_id;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(datateammain);
            lbl_isinama.Text = datateammain.Rows[0][0].ToString();
            lbl_isiteam.Text = datateammain.Rows[0][1].ToString();
            lbl_isipos.Text = datateammain.Rows[0][3].ToString();
            lbl_isination.Text = datateammain.Rows[0][2].ToString();
            lbl_isiplaypos.Text = datateammain.Rows[0][4].ToString();

            string simpan3 = cmb_player.GetItemText(cmb_player.SelectedItem).ToString();
            sqlQuery = $"SELECT `type` as 'Cards' FROM dmatch d, player p WHERE d.player_id = p.player_id and p.player_name = '{simpan3}';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(datateammain);

            for (int i = 0; i < datateammain.Rows.Count; i++)
            {
                if (datateammain.Rows[i][0].ToString() == "CY")
                {
                    yellow++;
                }
                if (datateammain.Rows[i][0].ToString() == "CR")
                {
                    red++;
                }
                if (datateammain.Rows[i][0].ToString() == "GO")
                {
                    goal++;
                }
                if (datateammain.Rows[i][0].ToString() == "PM")
                {
                    penalty++;
                }
            }
            lbl_isiyellow.Text = yellow.ToString();
            lbl_isired.Text = red.ToString();
            lbl_isigoal.Text = goal.ToString();
            lbl_isipenalty.Text = penalty.ToString();
        }

        private void cmb_team2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

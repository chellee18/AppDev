﻿namespace THA_WEEK_8_Michelle_P
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.playerDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showMatchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnl_player = new System.Windows.Forms.Panel();
            this.lbl_isiteam = new System.Windows.Forms.Label();
            this.lbl_isipos = new System.Windows.Forms.Label();
            this.lbl_isination = new System.Windows.Forms.Label();
            this.lbl_isiplaypos = new System.Windows.Forms.Label();
            this.lbl_isiyellow = new System.Windows.Forms.Label();
            this.lbl_isired = new System.Windows.Forms.Label();
            this.lbl_isigoal = new System.Windows.Forms.Label();
            this.lbl_isipenalty = new System.Windows.Forms.Label();
            this.lbl_isinama = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_player = new System.Windows.Forms.ComboBox();
            this.cmb_team = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_showmatch = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.pnl_player.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.playerDataToolStripMenuItem,
            this.showMatchToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1090, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // playerDataToolStripMenuItem
            // 
            this.playerDataToolStripMenuItem.Name = "playerDataToolStripMenuItem";
            this.playerDataToolStripMenuItem.Size = new System.Drawing.Size(117, 29);
            this.playerDataToolStripMenuItem.Text = "Player Data";
            this.playerDataToolStripMenuItem.Click += new System.EventHandler(this.playerDataToolStripMenuItem_Click);
            // 
            // showMatchToolStripMenuItem
            // 
            this.showMatchToolStripMenuItem.Name = "showMatchToolStripMenuItem";
            this.showMatchToolStripMenuItem.Size = new System.Drawing.Size(126, 29);
            this.showMatchToolStripMenuItem.Text = "Show Match";
            this.showMatchToolStripMenuItem.Click += new System.EventHandler(this.showMatchToolStripMenuItem_Click);
            // 
            // pnl_player
            // 
            this.pnl_player.Controls.Add(this.lbl_isiteam);
            this.pnl_player.Controls.Add(this.lbl_isipos);
            this.pnl_player.Controls.Add(this.lbl_isination);
            this.pnl_player.Controls.Add(this.lbl_isiplaypos);
            this.pnl_player.Controls.Add(this.lbl_isiyellow);
            this.pnl_player.Controls.Add(this.lbl_isired);
            this.pnl_player.Controls.Add(this.lbl_isigoal);
            this.pnl_player.Controls.Add(this.lbl_isipenalty);
            this.pnl_player.Controls.Add(this.lbl_isinama);
            this.pnl_player.Controls.Add(this.label11);
            this.pnl_player.Controls.Add(this.label10);
            this.pnl_player.Controls.Add(this.label9);
            this.pnl_player.Controls.Add(this.label8);
            this.pnl_player.Controls.Add(this.label7);
            this.pnl_player.Controls.Add(this.label6);
            this.pnl_player.Controls.Add(this.cmb_player);
            this.pnl_player.Controls.Add(this.cmb_team);
            this.pnl_player.Controls.Add(this.label5);
            this.pnl_player.Controls.Add(this.label4);
            this.pnl_player.Controls.Add(this.label2);
            this.pnl_player.Controls.Add(this.label1);
            this.pnl_player.Controls.Add(this.label3);
            this.pnl_player.Location = new System.Drawing.Point(0, 35);
            this.pnl_player.Name = "pnl_player";
            this.pnl_player.Size = new System.Drawing.Size(1078, 465);
            this.pnl_player.TabIndex = 4;
            // 
            // lbl_isiteam
            // 
            this.lbl_isiteam.AutoSize = true;
            this.lbl_isiteam.Location = new System.Drawing.Point(144, 114);
            this.lbl_isiteam.Name = "lbl_isiteam";
            this.lbl_isiteam.Size = new System.Drawing.Size(63, 20);
            this.lbl_isiteam.TabIndex = 22;
            this.lbl_isiteam.Text = "______";
            // 
            // lbl_isipos
            // 
            this.lbl_isipos.AutoSize = true;
            this.lbl_isipos.Location = new System.Drawing.Point(144, 155);
            this.lbl_isipos.Name = "lbl_isipos";
            this.lbl_isipos.Size = new System.Drawing.Size(63, 20);
            this.lbl_isipos.TabIndex = 21;
            this.lbl_isipos.Text = "______";
            // 
            // lbl_isination
            // 
            this.lbl_isination.AutoSize = true;
            this.lbl_isination.Location = new System.Drawing.Point(144, 197);
            this.lbl_isination.Name = "lbl_isination";
            this.lbl_isination.Size = new System.Drawing.Size(63, 20);
            this.lbl_isination.TabIndex = 20;
            this.lbl_isination.Text = "______";
            // 
            // lbl_isiplaypos
            // 
            this.lbl_isiplaypos.AutoSize = true;
            this.lbl_isiplaypos.Location = new System.Drawing.Point(144, 240);
            this.lbl_isiplaypos.Name = "lbl_isiplaypos";
            this.lbl_isiplaypos.Size = new System.Drawing.Size(63, 20);
            this.lbl_isiplaypos.TabIndex = 19;
            this.lbl_isiplaypos.Text = "______";
            // 
            // lbl_isiyellow
            // 
            this.lbl_isiyellow.AutoSize = true;
            this.lbl_isiyellow.Location = new System.Drawing.Point(143, 284);
            this.lbl_isiyellow.Name = "lbl_isiyellow";
            this.lbl_isiyellow.Size = new System.Drawing.Size(63, 20);
            this.lbl_isiyellow.TabIndex = 18;
            this.lbl_isiyellow.Text = "______";
            // 
            // lbl_isired
            // 
            this.lbl_isired.AutoSize = true;
            this.lbl_isired.Location = new System.Drawing.Point(143, 325);
            this.lbl_isired.Name = "lbl_isired";
            this.lbl_isired.Size = new System.Drawing.Size(63, 20);
            this.lbl_isired.TabIndex = 17;
            this.lbl_isired.Text = "______";
            // 
            // lbl_isigoal
            // 
            this.lbl_isigoal.AutoSize = true;
            this.lbl_isigoal.Location = new System.Drawing.Point(143, 366);
            this.lbl_isigoal.Name = "lbl_isigoal";
            this.lbl_isigoal.Size = new System.Drawing.Size(63, 20);
            this.lbl_isigoal.TabIndex = 16;
            this.lbl_isigoal.Text = "______";
            // 
            // lbl_isipenalty
            // 
            this.lbl_isipenalty.AutoSize = true;
            this.lbl_isipenalty.Location = new System.Drawing.Point(143, 406);
            this.lbl_isipenalty.Name = "lbl_isipenalty";
            this.lbl_isipenalty.Size = new System.Drawing.Size(63, 20);
            this.lbl_isipenalty.TabIndex = 15;
            this.lbl_isipenalty.Text = "______";
            // 
            // lbl_isinama
            // 
            this.lbl_isinama.AutoSize = true;
            this.lbl_isinama.Location = new System.Drawing.Point(144, 74);
            this.lbl_isinama.Name = "lbl_isinama";
            this.lbl_isinama.Size = new System.Drawing.Size(63, 20);
            this.lbl_isinama.TabIndex = 14;
            this.lbl_isinama.Text = "______";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 406);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 20);
            this.label11.TabIndex = 13;
            this.label11.Text = "Penalty Missed:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 366);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 20);
            this.label10.TabIndex = 12;
            this.label10.Text = "Goal Scored:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 325);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 20);
            this.label9.TabIndex = 11;
            this.label9.Text = "Red Cards:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 284);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "Yellow Cards:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 240);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 20);
            this.label7.TabIndex = 9;
            this.label7.Text = "Playing Pos:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Nationality:";
            // 
            // cmb_player
            // 
            this.cmb_player.FormattingEnabled = true;
            this.cmb_player.Location = new System.Drawing.Point(402, 23);
            this.cmb_player.Name = "cmb_player";
            this.cmb_player.Size = new System.Drawing.Size(180, 28);
            this.cmb_player.TabIndex = 7;
            this.cmb_player.SelectedIndexChanged += new System.EventHandler(this.cmb_player_SelectedIndexChanged_1);
            // 
            // cmb_team
            // 
            this.cmb_team.FormattingEnabled = true;
            this.cmb_team.Location = new System.Drawing.Point(74, 23);
            this.cmb_team.Name = "cmb_team";
            this.cmb_team.Size = new System.Drawing.Size(180, 28);
            this.cmb_team.TabIndex = 6;
            this.cmb_team.SelectedIndexChanged += new System.EventHandler(this.cmb_team_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(340, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Player:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Team:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Team:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Position:";
            // 
            // pnl_showmatch
            // 
            this.pnl_showmatch.Location = new System.Drawing.Point(12, 36);
            this.pnl_showmatch.Name = "pnl_showmatch";
            this.pnl_showmatch.Size = new System.Drawing.Size(1052, 467);
            this.pnl_showmatch.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 531);
            this.Controls.Add(this.pnl_player);
            this.Controls.Add(this.pnl_showmatch);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnl_player.ResumeLayout(false);
            this.pnl_player.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem playerDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showMatchToolStripMenuItem;
        private System.Windows.Forms.Panel pnl_player;
        private System.Windows.Forms.Label lbl_isiteam;
        private System.Windows.Forms.Label lbl_isipos;
        private System.Windows.Forms.Label lbl_isination;
        private System.Windows.Forms.Label lbl_isiplaypos;
        private System.Windows.Forms.Label lbl_isiyellow;
        private System.Windows.Forms.Label lbl_isired;
        private System.Windows.Forms.Label lbl_isigoal;
        private System.Windows.Forms.Label lbl_isipenalty;
        private System.Windows.Forms.Label lbl_isinama;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_player;
        private System.Windows.Forms.ComboBox cmb_team;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_showmatch;
    }
}

